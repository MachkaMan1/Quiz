package com.project;

import java.util.*;

public class Quiz {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Pick a category");
        System.out.println(1 + " Java");
        System.out.println(2 + " Animals");
        System.out.println(3 + " Music");
        System.out.println(4 + " Drinks");
        int categoryChoice = input.nextInt();
        switch (categoryChoice) {
            case 1 -> defineCategory1(categoryChoice);
            case 2 -> defineCategory2(categoryChoice);
            case 3 -> defineCategory3(categoryChoice);
            case 4 -> defineCategory4(categoryChoice);
            default -> System.out.println("Invalid number");
        }
        System.out.print("You played in category ");
        switch (categoryChoice) {
            case 1 -> System.out.println("Java");
            case 2 -> System.out.println("Animals");
            case 3 -> System.out.println("Music");
            case 4 -> System.out.println("Drinks");
        }
        System.out.println("You answered all the questions correctly, great job!");
    }

    public static void defineCategory1(int categoryChoice) {
        String[] cat1Questions = {
                "When was java created?", "Who created java?", "What was java initially called?", "What type of variable stores text?"
        };
        shuffleQuestionsCat1(cat1Questions);
        String[][] cat1Answers = {
                {"1996", "1992", "1843", "2003"},
                {"James Gosling", "Guido van Rossum", "Bjarne Stroustrup", "Brendan Eich"},
                {"Oak", "Birch", "Toffee", "Latte"},
                {"String", "long", "char", "string"}
        };
        for (int i = 0; i < cat1Questions.length; i++) {
            System.out.println(cat1Questions[i]);
            if (i == 0) {
                switch (cat1Questions[i]) {
                    case "When was java created?" -> shuffleAnswersCat1Q1(cat1Answers, categoryChoice);

                    case "Who created java?" -> shuffleAnswersCat1Q2(cat1Answers, categoryChoice);

                    case "What was java initially called?" -> shuffleAnswersCat1Q3(cat1Answers, categoryChoice);

                    case "What type of variable stores text?" -> shuffleAnswersCat1Q4(cat1Answers, categoryChoice);

                }
            }
            if (i == 1) {
                switch (cat1Questions[i]) {
                    case "When was java created?" -> shuffleAnswersCat1Q1(cat1Answers, categoryChoice);

                    case "Who created java?" -> shuffleAnswersCat1Q2(cat1Answers, categoryChoice);

                    case "What was java initially called?" -> shuffleAnswersCat1Q3(cat1Answers, categoryChoice);

                    case "What type of variable stores text?" -> shuffleAnswersCat1Q4(cat1Answers, categoryChoice);

                }
            }
            if (i == 2) {
                switch (cat1Questions[i]) {
                    case "When was java created?" -> shuffleAnswersCat1Q1(cat1Answers, categoryChoice);

                    case "Who created java?" -> shuffleAnswersCat1Q2(cat1Answers, categoryChoice);

                    case "What was java initially called?" -> shuffleAnswersCat1Q3(cat1Answers, categoryChoice);

                    case "What type of variable stores text?" -> shuffleAnswersCat1Q4(cat1Answers, categoryChoice);

                }
            }
            if (i == 3) {
                switch (cat1Questions[i]) {
                    case "When was java created?" -> shuffleAnswersCat1Q1(cat1Answers, categoryChoice);

                    case "Who created java?" -> shuffleAnswersCat1Q2(cat1Answers, categoryChoice);

                    case "What was java initially called?" -> shuffleAnswersCat1Q3(cat1Answers, categoryChoice);

                    case "What type of variable stores text?" -> shuffleAnswersCat1Q4(cat1Answers, categoryChoice);

                }
            }
        }
    }

    public static void shuffleQuestionsCat1(String[] cat1Questions) {
        List<String> questionsList = Arrays.asList(cat1Questions);
        Collections.shuffle(questionsList);
        questionsList.toArray(cat1Questions);
    }

    public static void shuffleAnswersCat1Q1(String[][] cat1Answers, int categoryChoice) {
        List<String> answersList1 = Arrays.asList(cat1Answers[0]);
        Collections.shuffle(answersList1);
        answersList1.toArray(cat1Answers[0]);
        System.out.println(Arrays.toString(cat1Answers[0]));
        checkAnswerCat1Q1(answersList1, categoryChoice);
    }

    public static void shuffleAnswersCat1Q2(String[][] cat1Answers, int categoryChoice) {
        List<String> answersList2 = Arrays.asList(cat1Answers[1]);
        Collections.shuffle(answersList2);
        answersList2.toArray(cat1Answers[1]);
        System.out.println(Arrays.toString(cat1Answers[1]));
        checkAnswerCat1Q2(answersList2, categoryChoice);
    }

    public static void shuffleAnswersCat1Q3(String[][] cat1Answers, int categoryChoice) {
        List<String> answersList3 = Arrays.asList(cat1Answers[2]);
        Collections.shuffle(answersList3);
        answersList3.toArray(cat1Answers[2]);
        System.out.println(Arrays.toString(cat1Answers[2]));
        checkAnswerCat1Q3(answersList3, categoryChoice);
    }

    public static void shuffleAnswersCat1Q4(String[][] cat1Answers, int categoryChoice) {
        List<String> answersList4 = Arrays.asList(cat1Answers[3]);
        Collections.shuffle(answersList4);
        answersList4.toArray(cat1Answers[3]);
        System.out.println(Arrays.toString(cat1Answers[3]));
        checkAnswerCat1Q4(answersList4, categoryChoice);
    }

    public static void checkAnswerCat1Q1(List answersList1, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList1.indexOf("1996")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat1Q2(List answersList2, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList2.indexOf("James Gosling")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat1Q3(List answersList3, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList3.indexOf("Oak")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat1Q4(List answersList4, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList4.indexOf("String")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }

            System.exit(0);
        }
    }

    public static void defineCategory2(int categoryChoice) {
        String[] cat2Questions = {
                "Where do koalas live?", "What is the scientific name of the wolf?", "How much did the biggest Leatherback sea turtle weigh?", "How many breeds of dogs are there?"
        };
        shuffleQuestionsCat2(cat2Questions);
        String[][] cat2Answers = {
                {"Australia", "Japan", "South Africa", "China"},
                {"Canis lupus", "Vulpes vulpes", "Carassius auratus", "Ailuropoda melanoleuca"},
                {"916 kg", "753 kg", "237 kg", "349 kg"},
                {"341", "152", "63", "562"}
        };
        for (int i = 0; i < cat2Questions.length; i++) {
            System.out.println(cat2Questions[i]);
            if (i == 0) {
                switch (cat2Questions[i]) {
                    case "Where do koalas live?" -> shuffleAnswersCat2Q1(cat2Answers, categoryChoice);
                    case "What is the scientific name of the wolf?" -> shuffleAnswersCat2Q2(cat2Answers, categoryChoice);
                    case "How much did the biggest Leatherback sea turtle weigh?" -> shuffleAnswersCat2Q3(cat2Answers, categoryChoice);
                    case "How many breeds of dogs are there?" -> shuffleAnswersCat2Q4(cat2Answers, categoryChoice);
                }
            }
            if (i == 1) {
                switch (cat2Questions[i]) {
                    case "Where do koalas live?" -> shuffleAnswersCat2Q1(cat2Answers, categoryChoice);
                    case "What is the scientific name of the wolf?" -> shuffleAnswersCat2Q2(cat2Answers, categoryChoice);
                    case "How much did the biggest Leatherback sea turtle weigh?" -> shuffleAnswersCat2Q3(cat2Answers, categoryChoice);
                    case "How many breeds of dogs are there?" -> shuffleAnswersCat2Q4(cat2Answers, categoryChoice);
                }
            }
            if (i == 2) {
                switch (cat2Questions[i]) {
                    case "Where do koalas live?" -> shuffleAnswersCat2Q1(cat2Answers, categoryChoice);
                    case "What is the scientific name of the wolf?" -> shuffleAnswersCat2Q2(cat2Answers, categoryChoice);
                    case "How much did the biggest Leatherback sea turtle weigh?" -> shuffleAnswersCat2Q3(cat2Answers, categoryChoice);
                    case "How many breeds of dogs are there?" -> shuffleAnswersCat2Q4(cat2Answers, categoryChoice);
                }
            }
            if (i == 3) {
                switch (cat2Questions[i]) {
                    case "Where do koalas live?" -> shuffleAnswersCat2Q1(cat2Answers, categoryChoice);
                    case "What is the scientific name of the wolf?" -> shuffleAnswersCat2Q2(cat2Answers, categoryChoice);
                    case "How much did the biggest Leatherback sea turtle weigh?" -> shuffleAnswersCat2Q3(cat2Answers, categoryChoice);
                    case "How many breeds of dogs are there?" -> shuffleAnswersCat2Q4(cat2Answers, categoryChoice);
                }
            }
        }
    }

    public static void shuffleQuestionsCat2(String[] cat2Questions) {
        List<String> questionsList = Arrays.asList(cat2Questions);
        Collections.shuffle(questionsList);
        questionsList.toArray(cat2Questions);
    }

    public static void shuffleAnswersCat2Q1(String[][] cat2Answers, int categoryChoice) {
        List<String> answersList1 = Arrays.asList(cat2Answers[0]);
        Collections.shuffle(answersList1);
        answersList1.toArray(cat2Answers[0]);
        System.out.println(Arrays.toString(cat2Answers[0]));
        checkAnswerCat2Q1(answersList1, categoryChoice);
    }

    public static void shuffleAnswersCat2Q2(String[][] cat2Answers, int categoryChoice) {
        List<String> answersList2 = Arrays.asList(cat2Answers[1]);
        Collections.shuffle(answersList2);
        answersList2.toArray(cat2Answers[1]);
        System.out.println(Arrays.toString(cat2Answers[1]));
        checkAnswerCat2Q2(answersList2, categoryChoice);
    }

    public static void shuffleAnswersCat2Q3(String[][] cat2Answers, int categoryChoice) {
        List<String> answersList3 = Arrays.asList(cat2Answers[2]);
        Collections.shuffle(answersList3);
        answersList3.toArray(cat2Answers[2]);
        System.out.println(Arrays.toString(cat2Answers[2]));
        checkAnswerCat2Q3(answersList3, categoryChoice);
    }

    public static void shuffleAnswersCat2Q4(String[][] cat2Answers, int categoryChoice) {
        List<String> answersList4 = Arrays.asList(cat2Answers[3]);
        Collections.shuffle(answersList4);
        answersList4.toArray(cat2Answers[3]);
        System.out.println(Arrays.toString(cat2Answers[3]));
        checkAnswerCat2Q4(answersList4, categoryChoice);
    }

    public static void checkAnswerCat2Q1(List answersList1, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList1.indexOf("Australia")) {

            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat2Q2(List answersList2, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList2.indexOf("Canis lupus")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat2Q3(List answersList3, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList3.indexOf("916 kg")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat2Q4(List answersList4, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList4.indexOf("341")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Food");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void defineCategory3(int categoryChoice) {
        String[] cat3Questions = {
                "What is Snoop Dogg's full name?", "When did AC/DC record their first single?", "What disease did Michael Jackson have?", "What is the most popular music genre?"
        };
        shuffleQuestionsCat3(cat3Questions);
        String[][] cat3Answers = {
                {"Calvin Cordozar Broadus Jr.", "O'Shea Jackson", "Andre Romelle Young", "Shawn Corey Carter"},
                {"1974", "1986", "1967", "1979"},
                {"Vitiligo", "Eczema", "Psoriasis", "Melanoma"},
                {"Pop", "Rock", "Hip-Hop", "Metal"}
        };
        for (int i = 0; i < cat3Questions.length; i++) {
            System.out.println(cat3Questions[i]);
            if (i == 0) {
                switch (cat3Questions[i]) {
                    case "What is Snoop Dogg's full name?" -> shuffleAnswersCat3Q1(cat3Answers, categoryChoice);
                    case "When did AC/DC record their first single?" -> shuffleAnswersCat3Q2(cat3Answers, categoryChoice);
                    case "What disease did Michael Jackson have?" -> shuffleAnswersCat3Q3(cat3Answers, categoryChoice);
                    case "What is the most popular music genre?" -> shuffleAnswersCat3Q4(cat3Answers, categoryChoice);
                }
            }
            if (i == 1) {
                switch (cat3Questions[i]) {
                    case "What is Snoop Dogg's full name?" -> shuffleAnswersCat3Q1(cat3Answers, categoryChoice);
                    case "When did AC/DC record their first single?" -> shuffleAnswersCat3Q2(cat3Answers, categoryChoice);
                    case "What disease did Michael Jackson have?" -> shuffleAnswersCat3Q3(cat3Answers, categoryChoice);
                    case "What is the most popular music genre?" -> shuffleAnswersCat3Q4(cat3Answers, categoryChoice);
                }
            }
            if (i == 2) {
                switch (cat3Questions[i]) {
                    case "What is Snoop Dogg's full name?" -> shuffleAnswersCat3Q1(cat3Answers, categoryChoice);
                    case "When did AC/DC record their first single?" -> shuffleAnswersCat3Q2(cat3Answers, categoryChoice);
                    case "What disease did Michael Jackson have?" -> shuffleAnswersCat3Q3(cat3Answers, categoryChoice);
                    case "What is the most popular music genre?" -> shuffleAnswersCat3Q4(cat3Answers, categoryChoice);
                }
            }
            if (i == 3) {
                switch (cat3Questions[i]) {
                    case "What is Snoop Dogg's full name?" -> shuffleAnswersCat3Q1(cat3Answers, categoryChoice);
                    case "When did AC/DC record their first single?" -> shuffleAnswersCat3Q2(cat3Answers, categoryChoice);
                    case "What disease did Michael Jackson have?" -> shuffleAnswersCat3Q3(cat3Answers, categoryChoice);
                    case "What is the most popular music genre?" -> shuffleAnswersCat3Q4(cat3Answers, categoryChoice);
                }
            }
        }

    }

    public static void shuffleQuestionsCat3(String[] cat3Questions) {
        List<String> questionsList = Arrays.asList(cat3Questions);
        Collections.shuffle(questionsList);
        questionsList.toArray(cat3Questions);
    }

    public static void shuffleAnswersCat3Q1(String[][] cat3Answers, int categoryChoice) {
        List<String> answersList1 = Arrays.asList(cat3Answers[0]);
        Collections.shuffle(answersList1);
        answersList1.toArray(cat3Answers[0]);
        System.out.println(Arrays.toString(cat3Answers[0]));
        checkAnswerCat3Q1(answersList1, categoryChoice);
    }

    public static void shuffleAnswersCat3Q2(String[][] cat3Answers, int categoryChoice) {
        List<String> answersList2 = Arrays.asList(cat3Answers[1]);
        Collections.shuffle(answersList2);
        answersList2.toArray(cat3Answers[1]);
        System.out.println(Arrays.toString(cat3Answers[1]));
        checkAnswerCat3Q2(answersList2, categoryChoice);
    }

    public static void shuffleAnswersCat3Q3(String[][] cat3Answers, int categoryChoice) {
        List<String> answersList3 = Arrays.asList(cat3Answers[2]);
        Collections.shuffle(answersList3);
        answersList3.toArray(cat3Answers[2]);
        System.out.println(Arrays.toString(cat3Answers[2]));
        checkAnswerCat3Q3(answersList3, categoryChoice);
    }

    public static void shuffleAnswersCat3Q4(String[][] cat3Answers, int categoryChoice) {
        List<String> answersList4 = Arrays.asList(cat3Answers[3]);
        Collections.shuffle(answersList4);
        answersList4.toArray(cat3Answers[3]);
        System.out.println(Arrays.toString(cat3Answers[3]));
        checkAnswerCat3Q4(answersList4, categoryChoice);
    }

    public static void checkAnswerCat3Q1(List answersList1, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList1.indexOf("Calvin Cordozar Broadus Jr.")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat3Q2(List answersList2, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList2.indexOf("1974")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat3Q3(List answersList3, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList3.indexOf("Vitiligo")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat3Q4(List answersList4, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList4.indexOf("Pop")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void defineCategory4(int categoryChoice) {
        String[] cat4Questions = {
                "What is the first cocktail every created called?", "What is the main spirit in a Mojito?", "When was the Martini created?", "Who invented the Corpse Reviver?"
        };
        shuffleQuestionsCat4(cat4Questions);
        String[][] cat4Answers = {
                {"Old Fashioned", "Manhattan", "Sazerac", "Whiskey Fix"},
                {"Rum", "Brandy", "Gin", "Vodka"},
                {"1887", "1938", "1752", "1986"},
                {"Harry Craddock", "Ian Fleming", "Dale DeGroff", "Jerry Thomas"}
        };
        for (int i = 0; i < cat4Questions.length; i++) {
            System.out.println(cat4Questions[i]);
            if (i == 0) {
                switch (cat4Questions[i]) {
                    case "What is the first cocktail every created called?" -> shuffleAnswersCat4Q1(cat4Answers, categoryChoice);
                    case "What is the main spirit in a Mojito?" -> shuffleAnswersCat4Q2(cat4Answers, categoryChoice);
                    case "When was the Martini created?" -> shuffleAnswersCat4Q3(cat4Answers, categoryChoice);
                    case "Who invented the Corpse Reviver?" -> shuffleAnswersCat4Q4(cat4Answers, categoryChoice);
                }
            }
            if (i == 1) {
                switch (cat4Questions[i]) {
                    case "What is the first cocktail every created called?" -> shuffleAnswersCat4Q1(cat4Answers, categoryChoice);
                    case "What is the main spirit in a Mojito?" -> shuffleAnswersCat4Q2(cat4Answers, categoryChoice);
                    case "When was the Martini created?" -> shuffleAnswersCat4Q3(cat4Answers, categoryChoice);
                    case "Who invented the Corpse Reviver?" -> shuffleAnswersCat4Q4(cat4Answers, categoryChoice);
                }
            }
            if (i == 2) {
                switch (cat4Questions[i]) {
                    case "What is the first cocktail every created called?" -> shuffleAnswersCat4Q1(cat4Answers, categoryChoice);
                    case "What is the main spirit in a Mojito?" -> shuffleAnswersCat4Q2(cat4Answers, categoryChoice);
                    case "When was the Martini created?" -> shuffleAnswersCat4Q3(cat4Answers, categoryChoice);
                    case "Who invented the Corpse Reviver?" -> shuffleAnswersCat4Q4(cat4Answers, categoryChoice);
                }
            }
            if (i == 3) {
                switch (cat4Questions[i]) {
                    case "What is the first cocktail every created called?" -> shuffleAnswersCat4Q1(cat4Answers, categoryChoice);
                    case "What is the main spirit in a Mojito?" -> shuffleAnswersCat4Q2(cat4Answers, categoryChoice);
                    case "When was the Martini created?" -> shuffleAnswersCat4Q3(cat4Answers, categoryChoice);
                    case "Who invented the Corpse Reviver?" -> shuffleAnswersCat4Q4(cat4Answers, categoryChoice);
                }
            }
        }
    }

    public static void shuffleQuestionsCat4(String[] cat4Questions) {
        List<String> questionList = Arrays.asList(cat4Questions);
        Collections.shuffle(questionList);
        questionList.toArray(cat4Questions);

    }

    public static void shuffleAnswersCat4Q1(String[][] cat4Answers, int categoryChoice) {
        List<String> answersList1 = Arrays.asList(cat4Answers[0]);
        Collections.shuffle(answersList1);
        answersList1.toArray(cat4Answers[0]);
        System.out.println(Arrays.toString(cat4Answers[0]));
        checkAnswerCat4Q1(answersList1, categoryChoice);
    }

    public static void shuffleAnswersCat4Q2(String[][] cat4Answers, int categoryChoice) {
        List<String> answersList2 = Arrays.asList(cat4Answers[1]);
        Collections.shuffle(answersList2);
        answersList2.toArray(cat4Answers[1]);
        System.out.println(Arrays.toString(cat4Answers[1]));
        checkAnswerCat4Q2(answersList2, categoryChoice);
    }

    public static void shuffleAnswersCat4Q3(String[][] cat4Answers, int categoryChoice) {
        List<String> answersList3 = Arrays.asList(cat4Answers[2]);
        Collections.shuffle(answersList3);
        answersList3.toArray(cat4Answers[2]);
        System.out.println(Arrays.toString(cat4Answers[2]));
        checkAnswerCat4Q3(answersList3, categoryChoice);
    }

    public static void shuffleAnswersCat4Q4(String[][] cat4Answers, int categoryChoice) {
        List<String> answersList4 = Arrays.asList(cat4Answers[3]);
        Collections.shuffle(answersList4);
        answersList4.toArray(cat4Answers[3]);
        System.out.println(Arrays.toString(cat4Answers[3]));
        checkAnswerCat4Q4(answersList4, categoryChoice);
    }

    public static void checkAnswerCat4Q1(List answersList1, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList1.indexOf("Old Fashioned")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat4Q2(List answersList2, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList2.indexOf("Rum")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat4Q3(List answersList3, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList3.indexOf("1887")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }

    public static void checkAnswerCat4Q4(List answersList4, int categoryChoice) {
        Scanner input = new Scanner(System.in);
        int answer = input.nextInt();
        if (answer - 1 == answersList4.indexOf("Harry Craddock")) {
            System.out.println("You answered correctly!");
        } else {
            System.out.println("game over");
            System.out.print("You played in category ");
            switch (categoryChoice) {
                case 1 -> System.out.println("Java");
                case 2 -> System.out.println("Animals");
                case 3 -> System.out.println("Music");
                case 4 -> System.out.println("Drinks");
            }
            System.exit(0);
        }
    }
}